create definer = root@`192.168.1.%` trigger trigger_npo_announcement
    before insert
    on npo_announcement
    for each row
BEGIN
	declare auto_incr1 int unsigned default 0;
	IF (NEW.aid IS NULL || NEW.aid = 0) THEN
		SELECT AUTO_INCREMENT INTO auto_incr1 FROM information_schema.TABLES WHERE table_schema='stpv1_hn27032019' AND table_name='npo_announcement';
		IF (auto_incr1%2 = 0) THEN
			SET NEW.aid = auto_incr1 + 1;
		END IF;
	END IF;
END;

